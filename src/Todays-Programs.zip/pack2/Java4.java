package pack2;

public class Java4 {
        public static void main(String[] args) {

            Java3 j3 = new Java3();
            j3.c ='k';
    }

}
